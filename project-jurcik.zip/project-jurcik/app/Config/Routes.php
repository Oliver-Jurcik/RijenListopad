<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Hlavní (výchozí) stránka webu – volá kontroler Home a metodu index
$routes->get('/', 'Main::index');

// Další stránka – volá kontroler Main a metodu page2
$routes->get('page2', 'Main::page2');

// Další stránka – volá kontroler Main a metodu page3
$routes->get('page3', 'Main::page3');

// Další stránka – volá kontroler Main a metodu page4
$routes->get('page4', 'Main::page4');
