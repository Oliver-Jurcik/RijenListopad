<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
/*konnstruktor = inicializace objektu */
class Main extends BaseController
{
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        /* Zavolá původní inicializaci z BaseController
        *view = zaklad je stejny, lisi se jenom data, které se vykresluji
         */
        parent::initController($request, $response, $logger);
    }

    public function index()
    {
        echo view("main_page");
    }
    public function page2(){
        echo view("page2");
    }
    public function page3(){
        echo view("page3");
    }
    public function page4(){
        echo view("page4");
    }
}
