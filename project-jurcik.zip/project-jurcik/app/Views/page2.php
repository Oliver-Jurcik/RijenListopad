<?= $this->extend("layout/template") ?> <!-- view se ma zabalit do teto sablony, -->
<?= $this->section("content"); ?>

<?php // <?= anchor("/", " ctvrta stránka"); ?>
    
    <style>
    body {
      background-color: #b4adad;
      color: white;
    }

    .navbar {
      background-color: #a63737;
      padding: 0.8rem 1rem;
    }

    .navbar-brand, .nav-link {
      color: white !important;
      font-weight: 600;
    }

    .nav-link:hover, .navbar-brand:hover {
      color: #000 !important;
      background-color: rgba(255, 255, 255, 0.1);
      border-radius: 5px;
    }

    .player-card {
      display: flex;
      flex-direction: row;
      background-color: #000;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      cursor: pointer;
      height: 100%;
    }

    .player-card:hover {
      transform: scale(1.03);
      box-shadow: 0 6px 20px rgba(0,0,0,0.5);
    }

    .player-img-wrapper {
      position: relative;
      flex: 1;
      overflow: hidden;
    }

    .player-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .flag {
      position: absolute;
      top: 10px;
      left: 10px;
      font-size: 1.5rem;
      z-index: 2;
    }

    .player-info {
      flex: 1;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent);
      color: white;
      text-align: left;
    }

    a.text-decoration-none {
      color: inherit;
    }

    @media (max-width: 768px) {
      .player-card {
        flex-direction: column;
      }

      .player-info {
        text-align: center;
      }
    }
  </style>

<div class="container mt-5">
    <div class="row g-4">

      <!-- Karty -->
      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-gb-eng flag"></span>
              <img src="foto/harry kane.png" alt="Tadeáš Stoppen" class="player-img">
            </div>
            <div class="player-info">
              <h5>Harry Kane</h5>
              <p>Forwards</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-de flag"></span>
              <img src="foto/manuel.png" alt="Jan Kliment" class="player-img">
            </div>
            <div class="player-info">
              <h5>Manuel Neuer</h5>
              <p>Goalkeepers</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-de flag"></span>
              <img src="foto/joshua kimmich.png" alt="Matěj Hodaš" class="player-img">
            </div>
            <div class="player-info">
              <h5>Joshua Kimmich</h5>
              <p>Midfielders</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-sn flag"></span>
              <img src="foto/nikolas jakson.png" alt="Adam Dohnálek" class="player-img">
            </div>
            <div class="player-info">
              <h5>Nicolas Jackson</h5>
              <p>Forwards</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-gb-eng flag"></span>
              <img src="foto/olie.PNG" alt="Jiří Šilarna" class="player-img">
            </div>
            <div class="player-info">
              <h5>Michael Olise</h5>
              <p>Forwards</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-gf flag"></span>
              <img src="foto/dayot.png" alt="Radim Brete" class="player-img">
            </div>
            <div class="player-info">
              <h5>Dayot Upamecano</h5>
              <p>Defenders</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-kr flag"></span>
              <img src="foto/kim.PNG" alt="Radim Brete" class="player-img">
            </div>
            <div class="player-info">
              <h5>Minjae Kim</h5>
              <p>Defenders</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-de flag"></span>
              <img src="foto/jonathan.PNG" alt="Radim Brete" class="player-img">
            </div>
            <div class="player-info">
              <h5>Jonathan Tah</h5>
              <p>Defenders</p>
            </div>
          </div>
        </a>
      </div>

      <div class="col-12 col-md-6 col-lg-4">
        <a href="https://fcbayern.com/en/teams/first-team" class="text-decoration-none">
          <div class="player-card">
            <div class="player-img-wrapper">
              <span class="fi fi-fr flag"></span>
              <img src="foto/sacha.PNG" alt="Radim Brete" class="player-img">
            </div>
            <div class="player-info">
              <h5>Sacha Boey</h5>
              <p>Defenders</p>
            </div>
          </div>
        </a>
      </div>

    </div>
  </div>
  
<div class="container mt-5">
  <div class="team-info-section bg-dark text-white p-4 rounded" style="margin-left: 1rem; margin-right: 1rem;">
    <h3 class="mb-3">O týmu FC Bayern München</h3>
    <p>
      FC Bayern München je jedním z nejúspěšnějších fotbalových klubů na světě. Klub byl založen v roce 1900 
      a od té doby získal rekordní počet německých titulů, domácích pohárů i evropských trofejí. 
      Je známý svou ofenzivní hrou, silnou tradicí a ikonickými hráči jako Franz Beckenbauer, Oliver Kahn, 
      Philipp Lahm nebo aktuálně Harry Kane a Jamal Musiala. Domácím stadionem je moderní Allianz Arena v Mnichově.
    </p>
    <p>
      Bayern není jen klub – je to symbol německé preciznosti, vášně pro fotbal a neustálého úsilí o dokonalost.
    </p>
    <a href="https://fcbayern.com/en/teams/first-team" target="_blank" class="btn btn-danger mt-3">
      Více informací na oficiální stránce
    </a>
  </div>
</div>

<?= $this->endSection();?>