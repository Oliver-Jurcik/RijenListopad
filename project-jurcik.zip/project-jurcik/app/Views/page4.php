<?= $this->extend("layout/template") ?> <!-- view se ma zabalit do teto sablony, -->
<?= $this->section("content"); ?>

<?php // <?= anchor("/", " ctvrta stránka"); ?>


    <style>
    body {
      background-color: #b4adad;
      color: white;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    #cardscolor {
      background-color: #db4646;
      border-radius: 15px;
      padding: 30px 40px;
      max-width: 1500px;
      margin: 30px auto;
      box-sizing: border-box;
    }

    .cards-container {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-auto-rows: 280px;
      gap: 25px;
    }

    .card-custom {
      position: relative;
      border-radius: 15px;
      overflow: hidden;
      cursor: pointer;
      box-shadow: 0 8px 15px rgba(0, 0, 0, 0.4);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      background-color: #222; 
    }

    .card-custom:hover {
      transform: scale(1.03);
      box-shadow: 0 12px 20px rgba(0, 0, 0, 0.6);
      z-index: 10;
    }

    .card-custom.double-height {
      grid-row: span 2;
      grid-auto-rows: 280px;
    }

    .card-custom img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
      transition: transform 0.5s ease;
      user-select: none;
      pointer-events: none;
    }

    .card-custom:hover img {
      transform: scale(1.05);
    }

    .card-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 20px 25px;
      background: linear-gradient(0deg, rgba(0,0,0,0.8) 30%, transparent 100%);
      color: white;
      box-sizing: border-box;
      border-bottom-left-radius: 15px;
      border-bottom-right-radius: 15px;
      pointer-events: none;
    }

    .card-title {
      margin: 0 0 8px 0;
      font-weight: 900;
      font-size: 1.3rem;
      text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.7);
    }

    .card-text {
      margin: 0 0 12px 0;
      font-size: 0.95rem;
      line-height: 1.3;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
      max-height: 3.9em; 
      overflow: hidden;
    }

    .card-footer {
      font-size: 0.85rem;
      color: #ddd;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.7);
    }

    .navbar {
      background-color: #a63737;
      padding: 0.8rem 1rem;
    }

    .navbar-brand,
    .nav-link {
      color: white !important;
      font-weight: 600;
      transition: color 0.3s ease, background-color 0.3s ease;
    }

    .nav-link:hover,
    .navbar-brand:hover {
      color: #000 !important;
      background-color: rgba(255, 255, 255, 0.1);
      border-radius: 5px;
    }

    @media (max-width: 992px) {
      #cardscolor {
        padding: 20px;
      }
      .cards-container {
        grid-template-columns: repeat(2, 1fr);
        grid-auto-rows: 220px;
        gap: 18px;
      }
      .card-custom.double-height {
        grid-row: span 1;
      }
    }

    @media (max-width: 600px) {
      .cards-container {
        grid-template-columns: 1fr;
        grid-auto-rows: 220px;
      }
      .card-custom.double-height {
        grid-row: span 1;
      }
    }
  </style>

<div id="cardscolor">
    <div class="cards-container">
      <div class="card-custom">
        <img src="foto/obrazek1.avif" alt="Michal" />
        <div class="card-overlay">
          <p class="card-text">
            FC Bayern dominate Chelsea: Comments and reaction from around the world
          </p>
        </div>
      </div>

      <div class="card-custom">
        <img src="foto/obrazek2.avif" alt="Neuer" />
        <div class="card-overlay">
          <p class="card-text">
            Reaction to Champions League game against Chelsea – Manuel Neuer: ‘We’re riding a positive wave’
          </p>
        </div>
      </div>

      <div class="card-custom double-height">
        <img src="foto/michal.avif" alt="Big Card" />
        <div class="card-overlay">
          <p class="card-text">
            FC Bayern sign Nicolas Jackson on loan from Chelsea
          </p>
        </div>
      </div>

      <div class="card-custom">
        <img src="foto/obrazek5.avif" alt="Card 3" />
        <div class="card-overlay">
          <p class="card-text">From relegation battle to surprise side: A look at TSG</p>
        </div>
      </div>

      <div class="card-custom">
        <img src="foto/obrazek4.avif" alt="Card 4" />
        <div class="card-overlay">
          <p class="card-text">FC Bayern's press conference ahead of the away game at TSG Hoffenheim</p>
        </div>
      </div>
    </div>
  </div>

 <div class="container mt-5">
  <div class="team-info-section bg-dark text-white p-4 rounded" style="margin-left: 1rem; margin-right: 1rem;">
    <h3 class="mb-3">Novinky FC Bayern München</h3>
    <p>
      Sledujte nejnovější zprávy, zápasy, přestupy a aktuality z klubu FC Bayern München. Získejte přehled o 
      výsledcích, komentářích trenérů a hráčů, rozhovorech a exkluzivních akcích přímo z Allianz Areny.
    </p>
    <p>
      Buďte v obraze s tím, co se děje kolem týmu – od ligových zápasů po evropské soutěže a zajímavosti z klubového života.
    </p>
    <a href="https://fcbayern.com/en/news" target="_blank" class="btn btn-danger mt-3">
      Více informací na oficiální stránce
    </a>
  </div>
</div>

<?= $this->endSection();?>