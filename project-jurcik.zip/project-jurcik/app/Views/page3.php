<?= $this->extend("layout/template") ?> <!-- view se ma zabalit do teto sablony, -->
<?= $this->section("content"); ?>

<?php // <?= anchor("/", " ctvrta stránka"); ?>

    <style>
  body {
    background-color: #b4adad;
    color: white;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }

  #cardscolor {
    background-color: #db4646;
    border-radius: 15px;
    padding: 30px 40px;
    max-width: 1500px;
    margin: 30px auto;
  }

  .flag-icon {
    width: 20px;
    height: 15px;
  }

  table td, table th {
    color: white;
  }

  .table thead th {
    border-bottom: 2px solid #fff;
    font-weight: 700;
  }

  .table tbody tr {
    border-color: rgba(255, 255, 255, 0.3);
  }

  .table-secondary td {
    background-color: #c84040 !important;
    font-weight: bold;
    text-align: center;
  }

  .navbar {
    background-color: #a63737;
    padding: 0.8rem 1rem;
  }

  .navbar-brand,
  .nav-link {
    color: white !important;
    font-weight: 600;
    transition: color 0.3s ease, background-color 0.3s ease;
  }

  .nav-link:hover,
  .navbar-brand:hover {
    color: #000 !important;
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 5px;
  }

/* Sekce trofejí */
#trophies-section {
  background-color: #db4646;
  border-radius: 15px;
  padding: 40px 50px;
  max-width: 1500px;
  margin: 30px auto 60px auto;
  text-align: center;
}

#trophies-section h2 {
  margin-bottom: 10px;
}

#trophies-section p {
  margin-bottom: 30px;
  font-size: 1.1rem;
}

.trophy-card {
  background-color: #c84040;
  border-radius: 15px;
  padding: 25px 30px;
  text-align: center;
  transition: transform 0.3s, background-color 0.3s;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  max-width: 450px; 
  margin: auto;
}

.trophy-card:hover {
  transform: translateY(-5px);
  background-color: #ad3939;
}

.trophy-card img {
  max-width: 400px;  
  width: 100%;    
  height: auto;  
  margin-bottom: 15px;
  border-radius: 10px;
}

.trophy-card h5 {
  margin-bottom: 10px;
  font-size: 1.4rem; 
  font-weight: bold;
}

.trophy-card p {
  margin: 0;
  font-size: 1.1rem;   
}

</style>

<div id="cardscolor">
  <h2 class="mb-4 text-white">Přehled zápasů – September & October</h2>

  <table class="table table-bordered align-middle">
    <thead>
      <tr>
        <th>Datum</th>
        <th>Domácí</th>
        <th>Hosté</th>
        <th>Výsledek</th>
      </tr>
    </thead>
    <tbody>
      <tr class="table-secondary">
        <td colspan="4">Září 2025</td>
      </tr>
      <tr>
        <td>02.09.2025</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td><span class="fi fi-fr flag-icon"></span> Olympique Lyonnais</td>
        <td>2 : 1</td>
      </tr>
      <tr>
        <td>07.09.2025</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td><span class="fi fi-gb flag-icon"></span> Tottenham Hotspur</td>
        <td>4 : 0</td>
      </tr>
      <tr>
        <td>12.09.2025</td>
        <td><span class="fi fi-ch flag-icon"></span> Grasshopper Zurich</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td>1 : 2</td>
      </tr>
      <tr class="table-secondary">
        <td colspan="4">Říjen 2025</td>
      </tr>
      <tr>
        <td>27.10.2025</td>
        <td><span class="fi fi-de flag-icon"></span> SV Wehen Wiesbaden</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td>2 : 3</td>
      </tr>
      <tr>
        <td>30.10.2025</td>
        <td><span class="fi fi-de flag-icon"></span> FC Augsburg</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td>2 : 3</td>
      </tr>
      <tr>
        <td>02.11.2025</td>
        <td><span class="fi fi-gb flag-icon"></span> Chelsea FC</td>
        <td><span class="fi fi-de flag-icon"></span> FC Bayern Munich</td>
        <td>1 : 3</td>
      </tr>
    </tbody>
  </table>
</div>

<div id="trophies-section">
  <h2>Trofeje FC Bayern</h2>
  <p>Historické úspěchy, které psaly dějiny klubu.</p>

<div class="row g-4 justify-content-center">
  <div class="col-6 col-md-3">
    <div class="trophy-card">
      <a href="https://fcbayern.com/en/club/honours" target="_blank">
        <img src="foto/bundesliga2.avif" alt="Bundesliga">
      </a>
      <h5>Bundesliga</h5>
      <p>33 titulů (naposledy 2023)</p>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="trophy-card">
      <a href="https://fcbayern.com/en/club/honours" target="_blank">
        <img src="foto/championslegue.avif" alt="Champions League">
      </a>
      <h5>UEFA Champions League</h5>
      <p>6 titulů (naposledy 2020)</p>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="trophy-card">
      <a href="https://fcbayern.com/en/club/honours" target="_blank">
        <img src="foto/fifa world cup.avif" alt="FIFA Club World Cup">
      </a>
      <h5>FIFA Club World Cup</h5>
      <p>2 tituly (naposledy 2020)</p>
    </div>
  </div>

  <div class="col-6 col-md-3">
    <div class="trophy-card">
      <a href="https://fcbayern.com/en/club/honours" target="_blank">
        <img src="foto/uefa super cup.avif" alt="UEFA Super Cup">
      </a>
      <h5>UEFA Super Cup</h5>
      <p>2 tituly (naposledy 2020)</p>
    </div>
  </div>
</div>

<?= $this->endSection();?>