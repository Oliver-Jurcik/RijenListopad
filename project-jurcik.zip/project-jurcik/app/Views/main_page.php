<?= $this->extend("layout/template") ?> <!-- view se má zabalit do této šablony -->

<?= $this->section("content"); ?>

    <h1>Hlavní Nadpis</h1>

    <!-- Hypertextový odkaz vytvořený pomocí funkce anchor() v CodeIgniteru -->
    <?php // <?= anchor("/", " ctvrta stránka"); ?>

    <?php
        // Vlastnosti obrázku
        $imageProperties = array(
            "src"   => "images/image.jpg",
            "class" => "img-fluid"
        );

        // Zobrazení obrázku pomocí helperu img()
        echo img($imageProperties);

        // Další obrázek
        echo img("images/krokodilo.png");

        
        
    ?>

<style>
  body {
    background-color: #b4adad;
    color: white;
    font-family: Arial, sans-serif;
  }

  .navbar {
    background-color: #a63737;
  }

  .navbar-brand,
  .nav-link {
    color: white !important;
    font-weight: 600;
  }

  .nav-link:hover,
  .navbar-brand:hover {
    color: #000 !important;
    background-color: rgba(255,255,255,0.1);
    border-radius: 5px;
  }

  #customCarousel {
    background-color: #db4646;
    border-radius: 15px;
    padding: 20px;
    position: relative;
  }

  .carousel-item {
    user-select: none;
  }

  .carousel-text h5 {
    margin-bottom: 15px;
    font-weight: 600;
  }

  .carousel-text p {
    font-size: 1.1rem;
    line-height: 1.4;
  }

  .carousel-inner .row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
  }

  .carousel-text {
    flex: 1 1 40%;
    padding: 0 15px;
  }

  .carousel-image {
    flex: 1 1 60%;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 300px;
  }

  .carousel-image img {
    max-width: 100%;
    max-height: 100%;
    border-radius: 8px;
    object-fit: contain;
  }

  .carousel-control-prev,
  .carousel-control-next {
    top: 55%;
    width: 5%;
    transition: transform 0.3s ease;
  }

  .carousel-control-prev-icon,
  .carousel-control-next-icon {
    background-color: rgba(0,0,0,0.4);
    border-radius: 50%;
    background-size: 60% 60%;
    box-shadow: 0 2px 6px rgba(0,0,0,0.4);
    transition: all 0.3s ease;
  }

  .carousel-control-prev:hover .carousel-control-prev-icon,
  .carousel-control-next:hover .carousel-control-next-icon {
    background-color: rgba(0,0,0,0.8);
    transform: scale(1.2);
    box-shadow: 0 4px 12px rgba(0,0,0,0.6);
  }

  .carousel-indicators {
    position: static;
    margin-top: 15px;
    display: flex;
    justify-content: center;
    gap: 10px;
  }

  .carousel-inner,
  #customCarousel {
    pointer-events: none;
  }

  .carousel-control-prev,
  .carousel-control-next,
  .carousel-indicators button {
    pointer-events: auto;
  }

  .club-info {
    background-color: #db4646;
    border-radius: 15px;
    padding: 40px 50px;
    max-width: 1500px;
    margin: 50px auto;
    text-align: center;
    box-shadow: 0 8px 25px rgba(0,0,0,0.4);
  }

  .club-info h2 {
    margin-bottom: 20px;
    font-weight: 700;
  }

  .club-info p {
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 20px;
    text-align: justify;
  }

  .club-info .btn {
    margin-top: 20px;
    font-weight: 600;
  }

  .img-wrapper {
    width: 100%;
    height: 200px;
    overflow: hidden;
    border-radius: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .img-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .img-wrapper img:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.6);
  }

  .card-text {
    font-size: 1rem;
    margin-top: 5px;
    font-weight: 600;
  }

  /* Responzivita */
  @media (max-width: 768px) {
    .carousel-image {
      height: 250px;
    }

    .img-wrapper {
      height: 150px;
    }
  }

  @media (max-width: 576px) {
    .carousel-image {
      height: 200px;
    }

    .img-wrapper {
      height: 120px;
    }
  }
</style>

<!-- Carousel -->
<div class="container mt-5">
    <div id="customCarousel" class="carousel slide" data-bs-ride="false" data-bs-touch="false" data-bs-interval="false">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="row align-items-center">
            <div class="carousel-text">
              <h5>CF Christoph Freund</h5>
              <p>Sporting director</p>
            </div>
            <div class="carousel-image">
              <img src="foto/trener.PNG" alt="Christoph Freund">
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row align-items-center">
            <div class="carousel-text">
              <h5>VK Vincent Kompany</h5>
              <p>Coach</p>
            </div>
            <div class="carousel-image">
              <img src="foto/vincent.PNG" alt="Vincent Kompany">
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row align-items-center">
            <div class="carousel-text">
              <h5>FN Floribert N’Galula</h5>
              <p>Coach</p>
            </div>
            <div class="carousel-image">
              <img src="foto/albert.PNG" alt="Floribert N’Galula">
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="row align-items-center">
            <div class="carousel-text">
              <h5>RM René Marić</h5>
              <p>Coach</p>
            </div>
            <div class="carousel-image">
              <img src="foto/rene.PNG" alt="René Marić">
            </div>
          </div>
        </div>
      </div>

      <div class="carousel-indicators mt-3">
        <button type="button" data-bs-target="#customCarousel" data-bs-slide-to="0" class="active" aria-current="true"></button>
        <button type="button" data-bs-target="#customCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#customCarousel" data-bs-slide-to="2"></button>
        <button type="button" data-bs-target="#customCarousel" data-bs-slide-to="3"></button>
      </div>

      <button class="carousel-control-prev" type="button" data-bs-target="#customCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
        <span class="visually-hidden">Předchozí</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#customCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
        <span class="visually-hidden">Další</span>
      </button>
    </div>
  </div>

  <div class="container mt-5">
    <div class="club-info p-5 rounded shadow">
      <h2 class="text-center mb-4">O klubu FC Bayern München</h2>
      
      <p>
        FC Bayern München byl založen v roce 1900 a stal se jedním z nejúspěšnějších fotbalových klubů v Evropě i na světě. 
        Klub má bohatou historii plnou domácích titulů, evropských i světových úspěchů. 
        Allianz Arena, domovský stadion klubu, pojme více než 75 000 fanoušků a je symbolem moderního fotbalu.
      </p>
      <p>
        Bayern je známý svou ofenzivní a atraktivní hrou, výchovou mladých talentů a legendárními hráči, jako jsou Franz Beckenbauer, 
        Oliver Kahn, Philipp Lahm, Manuel Neuer nebo současné hvězdy Harry Kane a Jamal Musiala.
      </p>

      <div class="row text-center mt-4 g-4 justify-content-center">
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div class="card bg-dark text-white h-100 shadow-sm border-0">
            <div class="img-wrapper mx-auto">
              <img src="foto/arena.jpg" class="card-img-top rounded" alt="Allianz Arena">
            </div>
            <div class="card-body p-2">
              <p class="card-text mb-0">Allianz Arena</p>
            </div>
          </div>
        </div>
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div class="card bg-dark text-white h-100 shadow-sm border-0">
            <div class="img-wrapper mx-auto">
              <img src="foto/franz.jpeg" class="card-img-top rounded" alt="Franz Beckenbauer">
            </div>
            <div class="card-body p-2">
              <p class="card-text mb-0">Franz Beckenbauer</p>
            </div>
          </div>
        </div>
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div class="card bg-dark text-white h-100 shadow-sm border-0">
            <div class="img-wrapper mx-auto">
              <img src="foto/oliver.avif" class="card-img-top rounded" alt="Oliver Kahn">
            </div>
            <div class="card-body p-2">
              <p class="card-text mb-0">Oliver Kahn</p>
            </div>
          </div>
        </div>
        <div class="col-6 col-md-3 d-flex justify-content-center">
          <div class="card bg-dark text-white h-100 shadow-sm border-0">
            <div class="img-wrapper mx-auto">
              <img src="foto/manuel neuer.avif" class="card-img-top rounded" alt="Manuel Neuer">
            </div>
            <div class="card-body p-2">
              <p class="card-text mb-0">Manuel Neuer</p>
            </div>
          </div>
        </div>
      </div>

      <p class="mt-4">
        Sledujte nejnovější zprávy, zápasy, přestupy a aktuality přímo z klubu FC Bayern München. 
        Buďte v obraze s tím, co se děje kolem týmu – od ligových zápasů po evropské soutěže a zajímavosti z klubového života.
      </p>

      <div class="text-center">
        <a href="https://fcbayern.com/en/news" target="_blank" class="btn btn-danger btn-lg mt-3 shadow">
          Více novinek na oficiální stránce
        </a>
      </div>
    </div>
  </div>

<?= $this->endSection(); ?>
